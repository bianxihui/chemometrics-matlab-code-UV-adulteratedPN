									
function [x_pred_minmaxscaling] = minmaxscalingv(x_pred,ps_x)
pred_x               = mapminmax('apply',x_pred',ps_x);
x_pred_minmaxscaling   = pred_x';