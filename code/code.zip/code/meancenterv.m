% Mean Centering									
function [x_pred_meancenter]=meancenterv(x_pred,xmeancenter)
[m,n]=size(x_pred);
x_pred_meancenter = (x_pred-ones(m,1)*xmeancenter);
