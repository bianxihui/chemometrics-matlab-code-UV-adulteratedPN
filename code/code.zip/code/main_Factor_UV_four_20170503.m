clear;close all;clc
load UV_four_20170503;
meanornot = 1;
mean_method = 1;
switch mean_method
    case 1
       for i = 1:75
        Spectra(i,:)= mean(spectra(2*i-1:2*i,:));             
       end
       Target = target;
    case 2
       Spectra = spectra;
       Target((2*i-1):(2*i))  = target(i); 
end
for column = 1;
dataname   = ynames{column};
disp(dataname);
%-----------------------------��������ȷ��----------------------------------
switch column
    case 1
         maxrank = 10;%����MCCV���F�����������,RMSECV,Rcv RMSEP
                      %4.0000    5.0691    0.9872    3.7047
                      %ѵ������С������,RMSECV,Rcv Ԥ�⼯��RMSEP,Rp
                      %18.0000    2.4367    0.9972   10.0000    2.5688   0.9959
                      
    case 2
         maxrank = 10;%ݭ��MCCV���F�����������,RMSECV,Rcv RMSEP
                      %4.0000   17.8211    0.7597   18.8089                      
                      %ѵ������С������,RMSECV,Rcv Ԥ�⼯��RMSEP,Rp
                      %13.0000   11.1064    0.9293   13.0000    6.1066   0.9659
                      
    case 3
         maxrank = 10; %����MCCV���F�����������,RMSECV,Rcv RMSEP
                       %2.0000   21.5053    0.1564   29.6689
                       %ѵ������С������,RMSECV,Rcv Ԥ�⼯��RMSEP,Rp
                       %11.0000    9.6876    0.9066   14.0000    6.6276  0.9759
                       

    case 4
         maxrank = 3;  %������MCCV���F�����������,RMSECV,Rcv RMSEP
                       %3.0000    6.1201    0.9682    4.3744
                       %ѵ������С������,RMSECV,Rcv Ԥ�⼯��RMSEP,Rp
                       %5.0000    5.8408    0.9700    4.0000    4.3008   0.9893
                       
end 
X = Spectra;
Y = Target(:,column);
group_method = 2;%KS����
     switch group_method
     %-----------------KS�����ݻ��֣�ѵ����2/3��Ԥ�⼯1/3--------------------
     case 2
     [m,n]               = size(X);
     [model,test]        = kenstone(X,floor(2/3*m));
     x_train             = X(model,:);
     x_pred              = X(test,:);
     y_train             = Y(model);
     y_pred              = Y(test);
     %--------------Ũ��������3��ȡ1��ѵ����2/3��Ԥ�⼯1/3-----------------
     case 3
     [sort_Y,sort_int]   = sort(Y);
     [m,n]               = size(X);
     index_pred          = sort_int(1:3:m);
     x_pred              = X(index_pred,:);
     y_pred              = Y(index_pred);
     X(index_pred,:)     = [];
     Y(index_pred)       = [];
     x_train             = X;
     y_train             = Y;
     end
[m_train,n_train]        = size(x_train);
LV1 = 25;            LV2 = 25;
text_size                = 16;
runtimes                 = 500;
%------------------------------������֤-------------------------------------
[presses]                = mccvfactor(x_train,y_train,LV1,runtimes);
alpha                    = 0.10;
[factor_F]               = Haaland_Thomas_F_test(presses,m_train,alpha);
presses_factor           = presses(factor_F);
[presses_min,factor_min] = min(presses);
%----------------------------PLS�ⲿԤ��------------------------------------
for maxrank              = 1:LV2;
B                        = plsr(x_train,y_train,maxrank);
c                        = x_pred*B(:,maxrank);
rmsep_PLS(maxrank)       = rms(c-y_pred);
R_PLS                    = corrcoef(c,y_pred);
r_PLS(maxrank)           = R_PLS(1,2);
end
[rmsep_min,LV_min]       = min(rmsep_PLS);
%----------------------------ͼ�α�ʾ---------------------------------------
figure;plot(presses,'-b<','LineWidth',1.5,'MarkerEdgeColor','b');
       set(gca,'fontsize',text_size);title(ynames{column},'fontsize',text_size+1);
       xlabel('LV','fontsize',text_size);ylabel('PRESS','fontsize',text_size); 
       cell_string{1} = ['LV_F = ' num2str(factor_F)];
       cell_string{2} = ['PRESS_F = ' num2str(presses_factor)];    
       cell_string{3} = '\downarrow';
       text(factor_F,0.5*(max(presses)+min(presses)),cell_string,'fontsize',text_size-3);
       clear cell_string;
       cell_string{1} = ['LV_m_i_n = ' num2str(factor_min)];
       cell_string{2} = ['PRESS_m_i_n = ' num2str(presses_min)];    
       cell_string{3} = '\downarrow';
       text(factor_min,0.4*(max(presses)+min(presses)),cell_string,'fontsize',text_size-3);
       clear cell_string;
figure; plot(rmsep_PLS,'--r<','LineWidth',2,'MarkerEdgeColor','r');
       set(gca,'fontsize',text_size);title(ynames{column},'fontsize',text_size+1);
       xlabel('LV','fontsize',text_size);ylabel('RMSEP','fontsize',text_size); 
       cell_string{1} = ['LV_m_i_n = ' num2str(LV_min)];
       cell_string{2} = ['RMSEP_m_i_n = ' num2str(rmsep_min)];
       cell_string{3} = '\downarrow';
       text(LV_min,0.5*(max(rmsep_PLS)+min(rmsep_PLS)),cell_string,'fontsize',text_size-3);
       clear cell_string;
end