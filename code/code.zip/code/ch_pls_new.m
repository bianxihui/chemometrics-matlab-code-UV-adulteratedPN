function [p, q, w, b, t, u, x, y, l] = ch_pls(x, y, maxrank)
% PLS   Calculate factors and coefficients for Partial Least Squares regression.
% modified

[j,nf] = size(x);
k = 0;  %x = a';  y = c';
if nargin == 3, nf = maxrank; end
for h = 1:nf,
	u(:,h) = y(:,1);
	told(:,h) = zeros(j,1);
	t(:,h) = ones(j,1);
	while (sum(abs(told(:,h)-t(:,h)))) > (1e-12) & k < 100
		told(:,h) = t(:,h);
		k = k + 1;
		w(h,:)  = u(:,h)' * x / (u(:,h)' * u(:,h));
		w(h,:)  =  w(h,:) / sqrt(sum(w(h,:) .* w(h,:)));
		t(:,h)  = x * w(h,:)' / (w(h,:) * w(h,:)');
		q(h,:) = t(:,h)' * y / (t(:,h)' * t(:,h));
		u(:,h)  = y * q(h,:)'/ (q(h,:) * q(h,:)');
	end
    l(h) = k;
	k = 0;
    p(h,:) = t(:,h)' * x / (t(:,h)' * t(:,h));
%    [norm(p(h,:)) sqrt(sum(p(h,:) .* p(h,:)))]
%    p(h,:) = p(h,:) / sqrt(sum(p(h,:) .* p(h,:)));  % sum(p(h,:).*p(h,:))==(p(h,:)'*p(h,:) 
%    t(:,h)  = t(:,h) /  sqrt(sum(p(h,:) .* p(h,:)));
%    w(h,:)  = w(h,:) /  sqrt(sum(p(h,:) .* p(h,:)));  % ��ʡ��? sqrt()=1
    %
    b(h) = (u(:,h)' * t(:,h)) / (t(:,h)' * t(:,h));   % �����ڻع�ϵ��b
    x = x - (t(:,h) * p(h,:));
    y = y - (b(h) * t(:,h) * q(h,:));
end
