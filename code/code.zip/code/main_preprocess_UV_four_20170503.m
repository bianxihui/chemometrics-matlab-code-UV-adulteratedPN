clc;clear;close all
disp('ԭʼ���ݣ���ͬԤ�����������д�����RMSECV,RMSEP,ѵ������Ԥ�⼯��R')
load UV_four_20170503;
meanornot = 1;
mean_method = 1;
switch mean_method
    case 1
       for i = 1:75
        Spectra(i,:)= mean(spectra(2*i-1:2*i,:));             
       end
       Target = target;
    case 2
       Spectra = spectra;
       Target((2*i-1):(2*i))  = target(i); 
end
cal          = Spectra;
caltar       = Target;
for columm   = 4;
    names   = ynames;
    disp(names{columm});
    %---------------------------�ɵ����Ĳ���--------------------------------        
 switch columm
    case 1
         maxrank = 10;
         window0 = 23; window1 = 35; window2 = 77;%���ڣ�ȡ����,��СֵΪ3��
         scalen  = 58; waveletfunction = 'Haar';%С���任�ķֽ�߶ȼ�С������
    case 2
         maxrank = 8;        
         window0 = 27; window1 = 53; window2 = 99;%���ڣ�ȡ����,��СֵΪ3��
         scalen  = 57; waveletfunction = 'Haar';%С���任�ķֽ�߶ȼ�С������
    case 3
         maxrank = 10;
         window0 = 83; window1 = 37; window2 = 87;%���ڣ�ȡ����,��СֵΪ3��
         scalen  = 60; waveletfunction = 'Haar';%С���任�ķֽ�߶ȼ�С������
    case 4
         maxrank = 3;
         window0 = 99; window1 = 99; window2 = 73;%���ڣ�ȡ����,��СֵΪ3��
         scalen  = 60; waveletfunction = 'Haar';%С���任�ķֽ�߶ȼ�С������   
  end 
    [m,n]                           = size(cal);
    %-----------------KS�����ݻ��֣�ѵ����2/3��Ԥ�⼯1/3---------------------
    [model,test]                    = kenstone(cal,floor(2/3*m));
    x_train                         = cal(model,:);
    x_pred                          = cal(test,:);
    y_train                         = caltar(model,columm);
    y_pred                          = caltar(test,columm);
    [m_train,n_train]               = size(x_train);
    %-------------------------------PLS------------------------------------
    disp('ƫ��С����-PLS')
    b                               = simpls(x_train,y_train,maxrank);
    c                               = x_pred*b(:,maxrank);
    [c_train,valpresses]            = loocv(x_train,y_train,maxrank);
    disp('RMSECV,RMSEP,ѵ������Ԥ�⼯��R');
    rmsecv_PLS                      = sqrt(valpresses./m_train);
    rmsep_PLS                       = rms(c-y_pred);
    r_train                         = corrcoef(c_train,y_train);
    r_train                         = r_train(1,2);
    r_PLS                           = corrcoef(c,y_pred);
    r_PLS                           = r_PLS(1,2);
    disp([rmsecv_PLS,rmsep_PLS,r_train,r_PLS]);   
    clear b c c_train valpresses r_train 
    %-------------------------------SG-------------------------------------
    disp('S-Gƽ��');
    x_train_SG                      = sgdiff(x_train,2,window0,0);
    x_pred_SG                       = sgdiff(x_pred,2,window0,0);
    b                               = simpls(x_train_SG,y_train,maxrank);
    c                               = x_pred_SG*b(:,maxrank);
    [c_train,valpresses]            = loocv(x_train_SG,y_train,maxrank);
    rmsecv_SG                       = sqrt(valpresses./m_train);
    disp('RMSECV,RMSEP,ѵ������Ԥ�⼯��R');
    rmsep_SG                        = rms(c-y_pred);
    r_train                         = corrcoef(c_train,y_train);
    r_train                         = r_train(1,2);
    r_SG                            = corrcoef(c,y_pred);
    r_SG                            = r_SG(1,2);
    disp([rmsecv_SG,rmsep_SG,r_train,r_SG]);    
    clear b c c_train valpresses r_train
    % -------------------------------SNV------------------------------------
    disp('��׼��̬����-SNV');
    [xsnv1,meanx1,stdd1]            = snv(x_train);
    [xsnv2,meanx2,stdd2]            = snv(x_pred);
    b                               = simpls(xsnv1,y_train,maxrank);         
    c                               = xsnv2*b(:,maxrank);
    [c_train,valpresses]            = loocv(xsnv1,y_train,maxrank);
    disp('RMSECV,RMSEP,ѵ������Ԥ�⼯��R');
    rmsecv_SNV                      = sqrt(valpresses./m_train);
    rmsep_SNV                       = rms(c-y_pred);
    r_train                         = corrcoef(c_train,y_train);
    r_train                         = r_train(1,2);
    r_SNV                           = corrcoef(c,y_pred);
    r_SNV                           = r_SNV(1,2);
    disp([rmsecv_SNV,rmsep_SNV,r_train,r_SNV]);    
    clear b c c_train valpresses r_train
    %-------------------------------MSC------------------------------------
    disp('��Ԫɢ��У��-MSC');
    [xmsc1,Xmeancal]                = ch_mscnc(x_train);
    xmsc2                           = ch_mscnv(x_pred,Xmeancal);         
    b                               = simpls(xmsc1,y_train,maxrank);
    c                               = xmsc2*b(:,maxrank);
    [c_train,valpresses]            = loocv(xmsc1,y_train,maxrank);
    disp('RMSECV,RMSEP,ѵ������Ԥ�⼯��R');
    rmsecv_MSC                      = sqrt(valpresses./m_train);
    rmsep_MSC                       = rms(c-y_pred);
    r_train                         = corrcoef(c_train,y_train);
    r_train                         = r_train(1,2);
    r_MSC                           = corrcoef(c,y_pred);
    r_MSC                           = r_MSC(1,2);
    disp([rmsecv_MSC,rmsep_MSC,r_train,r_MSC]);    
    clear b c c_train valpresses r_train
    %------------------------------1st-------------------------------------
    disp('һ�׵�-1st');
    x_train_1st                     = sgdiff(x_train,2,window1,1);
    x_pred_1st                      = sgdiff(x_pred,2,window1,1);     
    b                               = simpls(x_train_1st,y_train,maxrank);
    c                               = x_pred_1st*b(:,maxrank);
    [c_train,valpresses]            = loocv(x_train_1st,y_train,maxrank);
    disp('RMSECV,RMSEP,ѵ������Ԥ�⼯��R');
    rmsecv_1st                      = sqrt(valpresses./m_train);
    rmsep_1st                       = rms(c-y_pred);
    r_train                         = corrcoef(c_train,y_train);
    r_train                         = r_train(1,2);
    r_1st                           = corrcoef(c,y_pred);
    r_1st                           = r_1st(1,2);
    disp([rmsecv_1st,rmsep_1st,r_train,r_1st]);    
    clear b c c_train valpresses r_train
    %-------------------------------2nd------------------------------------
    disp('���׵�-2nd');
    x_train_2nd                     = sgdiff(x_train,2,window2,2);
    x_pred_2nd                      = sgdiff(x_pred,2,window2,2);
    b                               = simpls(x_train_2nd,y_train,maxrank);
    c                               = x_pred_2nd*b(:,maxrank);
    [c_train,valpresses]            = loocv(x_train_2nd,y_train,maxrank);
    disp('RMSECV,RMSEP,ѵ������Ԥ�⼯��R');
    rmsecv_2nd                      = sqrt(valpresses./m_train);
    rmsep_2nd                       = rms(c-y_pred);
    r_train                         = corrcoef(c_train,y_train);
    r_train                         = r_train(1,2);
    r_2nd                           = corrcoef(c,y_pred);
    r_2nd                           = r_2nd(1,2);
    disp([rmsecv_2nd,rmsep_2nd,r_train,r_2nd]);
    clear b c c_train valpresses r_train
    %------------------------------CWT-------------------------------------
    disp('����С���任-CWT');
    [xcwt1]                         = wavderiv(x_train,waveletfunction,scalen);
    [xcwt2]                         = wavderiv(x_pred,waveletfunction,scalen);
    b                               = simpls(xcwt1,y_train,maxrank);   
    c                               = xcwt2*b(:,maxrank);
    [c_train,valpresses]            = loocv(xcwt1,y_train,maxrank);
    disp('RMSECV,RMSEP,ѵ������Ԥ�⼯��R');
    rmsecv_CWT                      = sqrt(valpresses./m_train);
    rmsep_CWT                       = rms(c-y_pred);
    r_train                         = corrcoef(c_train,y_train);
    r_train                         = r_train(1,2);
    r_CWT                           = corrcoef(c,y_pred);
    r_CWT                           = r_CWT(1,2);
    disp([rmsecv_CWT,rmsep_CWT,r_train,r_CWT]); 
    clear b c c_train valpresses r_train    
end        
 
