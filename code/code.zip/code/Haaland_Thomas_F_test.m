function [factor] = Haaland_Thomas_F_test(presses,m_train,alpha)
nc=length(presses);
[min_press,min_LV] = min(presses);
for i = 1:min_LV
    F(i)=presses(i)/min_press;
end
p = 1-2*alpha;
F_table = finv(p,m_train,m_train);
factor = find(F < F_table);
factor = factor(1);
end