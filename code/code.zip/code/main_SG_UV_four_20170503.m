clc;clear;close all
disp('ԭʼ���ݣ�SG��ͬ���ڶ�Ӧ��RMSECV,RMSEP,ѵ������Ԥ�⼯��R')
load UV_four_20170503;
meanornot = 1;
mean_method = 1;
switch mean_method
    case 1
       for i = 1:75
        Spectra(i,:)= mean(spectra(2*i-1:2*i,:));   
       end
       Target = target;
    case 2
       Spectra = spectra;
       Target((2*i-1):(2*i))  = target(i); 
end
cal          = Spectra;
caltar       = Target;
for columm   = 4
    dataname = ynames{columm};
    disp(dataname);
   %----------------------------��������ȷ��--------------------------------
   switch columm
    case 1
         maxrank = 10;     
    case 2
         maxrank = 8;         
    case 3
         maxrank = 10;      
    case 4
         maxrank = 3;
    end 
    [m,n]                     = size(cal);
    %-----------------KS�����ݻ��֣�ѵ����2/3��Ԥ�⼯1/3---------------------
    [model,test]                    = kenstone(cal,floor(2/3*m));
    x_train                         = cal(model,:);
    x_pred                          = cal(test,:);
    y_train                         = caltar(model,columm);
    y_pred                          = caltar(test,columm);
    [m_train,n_train]               = size(x_train);
    %-------------------------------PLS------------------------------------
    disp('ƫ��С����-PLS')
    b                               = simpls(x_train,y_train,maxrank);
    c                               = x_pred*b(:,maxrank);
    [c_train,valpresses]            = loocv(x_train,y_train,maxrank);
    disp('RMSECV,RMSEP,ѵ������Ԥ�⼯��R');
    rmsecv_PLS                      = sqrt(valpresses./m_train);
    rmsep_PLS                       = rms(c-y_pred);
    r_train                         = corrcoef(c_train,y_train);
    r_train                         = r_train(1,2);
    r_PLS                           = corrcoef(c,y_pred);
    r_PLS                           = r_PLS(1,2);
    disp([rmsecv_PLS,rmsep_PLS,r_train,r_PLS]);    
    clear b c c_train valpresses r_train 
    %---------------------------------------------------------------------
    ttt = 1;
    max_window = 100;
     for window = 3:2:max_window
         x_train_SG                 = sgdiff(x_train,2,window,0);
         x_pred_SG                  = sgdiff(x_pred,2,window,0);
         [c_train,valpresses]       = loocv(x_train_SG,y_train,maxrank);
         b                          = simpls(x_train_SG,y_train,maxrank);         
         c                          = x_pred_SG*b(:,maxrank);
         rmsecv_SG(ttt)             = sqrt(valpresses./m_train);
         R_train_SG                 = corrcoef(c_train,y_train);
         r_train_SG(ttt)            = R_train_SG(1,2);
         rmsep_SG(ttt)              = rms(c-y_pred);
         R_pred_SG                  = corrcoef(c,y_pred);
         r_pred_SG(ttt)             = R_pred_SG(1,2);
         ttt = ttt + 1;
     end
     min_index_RMSECV               = find(rmsecv_SG == min(rmsecv_SG));
     disp('��СRMSECV,R����Ӧ����Ѵ���');
     disp([rmsecv_SG(min_index_RMSECV) r_train_SG(min_index_RMSECV) min_index_RMSECV*2+1]);
     min_index_RMSEP                = find(rmsep_SG == min(rmsep_SG));
     disp('��СRMSEP,R����Ӧ����Ѵ���');
     disp([rmsep_SG(min_index_RMSEP) r_pred_SG(min_index_RMSEP) min_index_RMSEP*2+1]);
     text_size   = 16;
     figure;subplot(2,2,1);plot([3:2:max_window],rmsecv_SG,'r*-','LineWidth',2);set(gca,'fontsize',text_size);title(dataname,'fontsize',text_size+1);
                           xlabel('Window','fontsize',text_size);ylabel('RMSECV','fontsize',text_size);
            subplot(2,2,2);plot([3:2:max_window],r_train_SG,'bp-','LineWidth',2);set(gca,'fontsize',text_size);title(dataname,'fontsize',text_size+1);
                           xlabel('Window','fontsize',text_size);ylabel('R-train','fontsize',text_size);
            subplot(2,2,3);plot([3:2:max_window],rmsep_SG,'go-','LineWidth',2);set(gca,'fontsize',text_size);title(dataname,'fontsize',text_size+1);
                           xlabel('Window','fontsize',text_size);ylabel('RMSEP','fontsize',text_size);
            subplot(2,2,4);plot([3:2:max_window],r_pred_SG,'k+-','LineWidth',2);set(gca,'fontsize',text_size);title(dataname,'fontsize',text_size+1);
                           xlabel('Window','fontsize',text_size);ylabel('R-pred','fontsize',text_size);
            
end     