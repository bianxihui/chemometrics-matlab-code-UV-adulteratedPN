
									
function [ps_x,x_train_minmaxscaling,ps_y,y_train_minmaxscaling] = minmaxscalingc(x_train,y_train)
[train_x,ps_x]       = mapminmax(x_train');
ps_x.ymin              = 0;
[train_x,ps_x]       = mapminmax(x_train',ps_x);
[train_y,ps_y]       = mapminmax(y_train');
ps_y.ymin              = 0;
[train_y,ps_y]       = mapminmax(y_train',ps_y);
x_train_minmaxscaling  = train_x';
y_train_minmaxscaling  = train_y';