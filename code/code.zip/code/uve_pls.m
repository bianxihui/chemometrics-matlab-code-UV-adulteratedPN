function [ss1,ss2,maxnoise]=uve_pls(cal,caltar,factor);

%%

[cala,calb]=size(cal);
randc=randn(cala,calb)*10^(-15);
cal0=[cal randc]; 

for i=1:cala
    x1=cal0;y1=caltar;
   x1(i,:)=[];y1(i,:)=[];  
   B=simpls(x1,y1,factor);
   coefs(i,:)=B(:,factor)';   
   
end 

ss=mean(coefs)./std(coefs);
ss1=ss(1:calb);  ss2=ss(calb+1:2*calb); 
maxnoise=max(abs(ss2));  
 
 
  
     
