function BB = uvemc(x,y,mcv,maxrank);

[n,m] = size(x);
for i=1:mcv
    %home,disp(['MCCV ', num2str(i), ' of ', num2str(mcv)]);
    list = randperm(n); 
    mcvlist = list(1:floor(3*n/4));
    y11 = y;
    x11 = x;
    x22 = x11(mcvlist,:);
    y22 = y11(mcvlist);
%    x11(mcvlist,:)=[];
%    y11(mcvlist)=[];
    B = simpls(x22, y22, maxrank);
%   cc11(mcvlist) = x22*B(:,maxrank)
    BB(i,:) = B(:,maxrank)';
end
