function [factor]=adjust_wold(presses)
nc=length(presses);
for i=1:nc-1
    R(i)=presses(i+1)/presses(i);
end
factor=find(R>0.90);
if factor(1)==1
    factor=factor(2);
else
    factor=factor(1);
end