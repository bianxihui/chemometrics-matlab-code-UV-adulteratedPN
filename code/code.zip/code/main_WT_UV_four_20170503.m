clc;clear;close all
disp('ԭʼ���ݣ���ͬС���������ֽ�߶ȶ�Ӧ��RMSECV,RMSEP,ѵ������Ԥ�⼯��R')
load UV_four_20170503;
meanornot = 1;
mean_method = 1;
switch mean_method
    case 1
       for i = 1:75
        Spectra(i,:)= mean(spectra(2*i-1:2*i,:));             
       end
       Target = target;
    case 2
       Spectra = spectra;
       Target((2*i-1):(2*i))  = target(i); 
end
cal          = Spectra;
caltar       = Target;
for columm   = 1;
    dataname = ynames{columm};
    disp(dataname);      
   %----------------------------��������ȷ��--------------------------------
   switch columm
    case 1
         maxrank = 10;        
    case 2
         maxrank = 8;         
    case 3
         maxrank = 10;  
    case 4
         maxrank = 3;
    end 
    [m,n]                     = size(cal);
    %-----------------KS�����ݻ��֣�ѵ����2/3��Ԥ�⼯1/3---------------------
    [model,test]                   = kenstone(cal,floor(2/3*m));
    x_train                        = cal(model,:);
    x_pred                         = cal(test,:);
    y_train                        = caltar(model,columm);
    y_pred                         = caltar(test,columm);
    [m_train,n_train]              = size(x_train);
name ={'Haar', 'db2','db3','db4','db5','db6','db7','db8','db9','db10','db11','db12','db13','db14','db15','db16','db17','db18','db19','db20',...
       'coif1','coif2','coif3','coif4','coif5','sym2','sym3','sym4','sym5','sym6','sym7','sym8',...
       'bior1.1','bior1.3','bior1.5','bior2.2','bior2.4','bior2.6','bior2.8',...
       'bior3.1', 'bior3.3' , 'bior3.5', 'bior3.7', 'bior3.9', 'bior4.4' , 'bior5.5', 'bior6.8'};
[x_train,Xmeancal]                = ch_mscnc(x_train);
x_pred                            = ch_mscnv(x_pred,Xmeancal);
[x_train,meanx1,stdd1]             = snv(x_train);
[x_pred,meanx2,stdd2]              = snv(x_pred);
for i=1:32 %ֻ��SYM8֮ǰ��С������32����ȫ��С������47��    
    for scale =1:60    
        [data1]                    = wavderiv(x_train,name{i},scale);
        [data2]                    = wavderiv(x_pred,name{i},scale);
        [p, q, w, b]               = ch_pls_new(data1,y_train,maxrank);   
        c                          = ch_plspred(data2, p, q, w, b,maxrank);
        rmsep_CWT(i,scale)         = rms(c-y_pred);
        R_CWT                      = corrcoef(c,y_pred);
        r_CWT(i,scale)             = R_CWT(1,2);         
        recovery_CWT               = 100*c./y_pred;
        max_recovery_CWT(i,scale)  = max(recovery_CWT);
        min_recovery_CWT(i,scale)  = min(recovery_CWT);                        
     end
end
[min_function,min_scale]    = find(rmsep_CWT == min(min(rmsep_CWT)));
disp('RMSEP��Сֵ��Ӧ��С�������ͷֽ�߶�');
disp(name{min_function});
disp(min_scale);
text_size                = 16;
figure; mesh(rmsep_CWT);
        set(gca,'fontsize',text_size);
        title( ynames{columm},'fontsize',text_size+1);
        xlabel('Scales','fontsize',text_size);
        ylabel('Wavelet Functions','fontsize',text_size);
        zlabel('RMSEP');
end
