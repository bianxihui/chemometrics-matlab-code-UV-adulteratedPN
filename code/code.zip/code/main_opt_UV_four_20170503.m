clc;clear;close all
disp('��ҩ���ݣ����Ԥ����������Ӧ��RMSECV,RMSEP,ѵ������Ԥ�⼯��R')
load UV_four_20170503;
meanornot = 1;
mean_method = 1;
switch mean_method
    case 1
       for i = 1:75
        Spectra(i,:)= mean(spectra(2*i-1:2*i,:));
       end
       Target = target;
    case 2
       Spectra = spectra;
       Target((2*i-1):(2*i))  = target(i); 
end
cal          = Spectra;
caltar       = Target;
[m,n]        = size(cal);
for columm   = 2;
    dataname = ynames{columm};
    disp(dataname);     
    %-----------------KS�����ݻ��֣�ѵ����2/3��Ԥ�⼯1/3-------------------------
    [model,test]           = kenstone(cal,floor(2/3*m));
    x_train0               = cal(model,:);
    x_pred0                = cal(test,:);
    y_train                = caltar(model,columm);
    y_pred                 = caltar(test,columm);
    meanxtrain0            = mean(x_train0);
    switch columm
    case 1
         maxrank = 10;
         window0 = 23; window1 = 35; window2 = 77;%���ڣ�ȡ����,��СֵΪ3��
         scalen  = 58; waveletfunction = 'Haar';%С���任�ķֽ�߶ȼ�С������
         %------------------���Ԥ���������Թ��׽���Ԥ����-------------------
         x_train                   = sgdiff(x_train0,2,window2,2);
         x_pred                    = sgdiff(x_pred0,2,window2,2);
    case 2
         maxrank = 8;
         window0 = 27; window1 = 53; window2 = 99;%���ڣ�ȡ����,��СֵΪ3��
         scalen  = 57; waveletfunction = 'Haar';%С���任�ķֽ�߶ȼ�С������ 
         %------------------���Ԥ���������Թ��׽���Ԥ����-------------------
         x_train                   = sgdiff(x_train0,2,window1,1);
         x_pred                    = sgdiff(x_pred0,2,window1,1);          
    case 3
         maxrank = 10;
         window0 = 83; window1 = 37; window2 = 87;%���ڣ�ȡ����,��СֵΪ3��
         scalen  = 60; waveletfunction = 'Haar';%С���任�ķֽ�߶ȼ�С������
         %------------------���Ԥ���������Թ��׽���Ԥ����-------------------
         x_train                   = wavderiv(x_train0,waveletfunction,scalen);
         x_pred                    = wavderiv(x_pred0,waveletfunction,scalen);
    case 4
         maxrank = 3;
         window0 = 99; window1 = 99; window2 = 73;%���ڣ�ȡ����,��СֵΪ3��
         scalen  = 60; waveletfunction = 'Haar';%С���任�ķֽ�߶ȼ�С������
         %------------------���Ԥ���������Թ��׽���Ԥ����-------------------
          x_train                   = sgdiff(x_train0,2,window0,0);
          x_pred                    = sgdiff(x_pred0,2,window0,0);
%          x_train                    = x_train0;
%          x_pred                     = x_pred0;
   end 
   [m_train,n_train]          = size(x_train);  
   %-------------------------UVE+PLS---------------------------------------
   disp('UVE+PLS')
   [stability1,ss2,maxnoise]  = uve_pls(x_train,y_train,maxrank);          
   %figure; plot(stability1);title('stability-UVE');
   [m,n]                      = sort(abs(stability1));
   ind_UVE                    = fliplr(n);
   disp('�����Ĳ����㣬RMSECV,RMSEP,��ģ����Ԥ�⼯��R');
   rmsecvs_uve                = [];
   rmseps_uve                 = [];
   cs_train                   = [];
   cs_uve                     = [];
   for i = 25:5:length(ind_UVE)
       b_uve                  = simpls(x_train(:,ind_UVE(1:i)),y_train,maxrank);
       c_uve                  = x_pred(:,ind_UVE(1:i))*b_uve(:,maxrank);
       [c_train,valpress]     = loocv(x_train(:,ind_UVE(1:i)),y_train,maxrank);
       rmsecvs_uve            = [rmsecvs_uve;i sqrt(valpress./m_train)];
       rmseps_uve             = [rmseps_uve; i rms(c_uve-y_pred)];
       cs_train               = [cs_train,c_train];
       cs_uve                 = [cs_uve,c_uve];
   end        
   [rmsep_uve(columm), ind2]  = min(rmseps_uve(:,2));
   rmsecv_uve(columm)         = rmsecvs_uve(ind2,2);
   cmin_train                 = cs_train(:,ind2);
   cmin_uve                   = cs_uve(:,ind2);
   R_train                    = corrcoef(cmin_train,y_train);
   R_uve                      = corrcoef(cmin_uve,y_pred);
   r_uve(columm)              = R_uve(1,2);
   r_train(columm)            = R_train(1,2);
   min_num2(columm)           = rmseps_uve(ind2,1);
   disp(min_num2(columm));
   disp([rmsecv_uve(columm),rmsep_uve(columm),r_train(columm),r_uve(columm)]);
   disp('�����������Сֵ');        
   recovery_UVEPLS            = 100*cmin_uve./y_pred;
   max_recovery_UVEPLS        = max(recovery_UVEPLS);
   min_recovery_UVEPLS        = min(recovery_UVEPLS);
   disp([max_recovery_UVEPLS,min_recovery_UVEPLS]);   
    
   %-----------------------MCUVE+PLS--------------------------------------
   disp('MCUVE+PLS')
   BB2                        = uvemc(x_train,y_train,1000,maxrank);
   stability2                 = mean(BB2)./std(BB2);
   %figure; plot(stability2);title('stability-MCUVE');
   [m,n]                      = sort(abs(stability2));        
   ind_MCUVE                  = fliplr(n);
   disp('�����Ĳ����㣬RMSECV,RMSEP,��ģ����Ԥ�⼯��R');
   rmsecvs_mcuve              = [];
   rmseps_mcuve               = [];
   cs_train                   = [];
   cs_mcuve                   = [];
   for i = 25:5:length(ind_MCUVE)
       b_mcuve                = simpls(x_train(:,ind_MCUVE(1:i)),y_train,maxrank);
       c_mcuve                = x_pred(:,ind_MCUVE(1:i))*b_mcuve(:,maxrank);
       [c_train,valpress]     = loocv(x_train(:,ind_MCUVE(1:i)),y_train,maxrank);
       rmsecvs_mcuve          = [rmsecvs_mcuve;i sqrt(valpress./m_train)];
       rmseps_mcuve           = [rmseps_mcuve; i rms(c_mcuve-y_pred)]; 
       cs_train               = [cs_train,c_train];
       cs_mcuve               = [cs_mcuve,c_mcuve];
   end
   
   [rmsep_mcuve(columm), ind3]= min(rmseps_mcuve(:,2));
   rmsecv_mcuve(columm)       = rmsecvs_mcuve(ind3,2);
   cmin_train                 = cs_train(:,ind3);
   cmin_mcuve                 = cs_mcuve(:,ind3);
   R_train                    = corrcoef(cmin_train,y_train);
   R_mcuve                    = corrcoef(cmin_mcuve,y_pred);
   r_mcuve(columm)            = R_mcuve(1,2);
   r_train(columm)            = R_train(1,2);        
   min_num3(columm)           = rmseps_mcuve(ind3,1);
   disp(min_num3(columm));
   disp([rmsecv_mcuve(columm),rmsep_mcuve(columm),r_train(columm),r_mcuve(columm)]);
   disp('�����������Сֵ');
   recovery_MCUVEPLS          = 100*cmin_mcuve./y_pred;
   max_recovery_MCUVEPLS      = max(recovery_MCUVEPLS);
   min_recovery_MCUVEPLS      = min(recovery_MCUVEPLS);
   disp([max_recovery_MCUVEPLS,min_recovery_MCUVEPLS]);    
      
   %-------------------------RT+PLS----------------------------------------
   disp('RT+PLS')
   [P]                        = randomizationtest(x_train,y_train,1000, maxrank);
   disp('�����Ĳ����㣬RMSECV,RMSEP,��ģ����Ԥ�⼯��R');
   rmsecvs_rt                 = [];
   rmseps_rt                  = [];
   cs_train                   = [];
   cs_rt                      = [];
   [m,ind_RT]                 = sort(P);
   for i = 25:5:length(ind_RT)
       b_rt                   = simpls(x_train(:,ind_RT(1:i)),y_train,maxrank);
       c_rt                   = x_pred(:,ind_RT(1:i))*b_rt(:,maxrank);
       [c_train,valpress]     = loocv(x_train(:,ind_RT(1:i)),y_train,maxrank);
       rmsecvs_rt             = [rmsecvs_rt;i sqrt(valpress./m_train)];
       rmseps_rt              = [rmseps_rt; i rms(c_rt-y_pred)];
       cs_train               = [cs_train,c_train];
       cs_rt                  = [cs_rt,c_rt];
   end
   [rmsep_rt(columm),ind1]    = min(rmseps_rt(:,2));
   rmsecv_rt(columm)          = rmsecvs_rt(ind1,2);
   cmin_train                 = cs_train(:,ind1);
   cmin_rt                    = cs_rt(:,ind1);
   R_train                    = corrcoef(cmin_train,y_train);
   R_rt                       = corrcoef(cmin_rt,y_pred);
   r_train(columm)            = R_train(1,2);
   r_rt(columm)               = R_rt(1,2);
   min_num1(columm)           = rmseps_rt(ind1,1);
   disp(min_num1(columm));
   disp([rmsecv_rt(columm),rmsep_rt(columm),r_train(columm),r_rt(columm)]);
   %figure; plot(P);title('P');
   disp('�����������Сֵ');
   recovery_RTPLS             = 100*cmin_rt./y_pred;
   max_recovery_RTPLS         = max(recovery_RTPLS);
   min_recovery_RTPLS         = min(recovery_RTPLS);
   disp([max_recovery_RTPLS,min_recovery_RTPLS]);     
   %----------------------------------------------------------------------      
   AAA_UVE                    = sort(ind_UVE(1:min_num2(columm)));
   wavelength_UVE             = wavelength(AAA_UVE);
   AAA_x_train_UVE            = meanxtrain0(AAA_UVE);
   AAA_MCUVE                  = sort(ind_MCUVE(1:min_num3(columm)));
   wavelength_MCUVE           = wavelength(AAA_MCUVE);
   AAA_x_train_MCUVE          = meanxtrain0(AAA_MCUVE);
   AAA_RT                     = sort(ind_RT(1:min_num1(columm)));
   wavelength_RT              = wavelength(AAA_RT);
   AAA_x_train_RT             = meanxtrain0(AAA_RT);
   figure;         
   subplot(2,3,1);plot(rmseps_uve(:,1),rmseps_uve(:,2),'-bo');title('rmseps-UVE');
   subplot(2,3,4);plot(wavelength,meanxtrain0,'b-');hold on;plot(wavelength_UVE,AAA_x_train_UVE,'r*');
   subplot(2,3,2);plot(rmseps_mcuve(:,1),rmseps_mcuve(:,2),'-bo');title('rmseps-MCUVE');
   subplot(2,3,5);plot(wavelength,meanxtrain0,'b-');hold on;plot(wavelength_MCUVE,AAA_x_train_MCUVE,'r*'); 
   subplot(2,3,3);plot(rmseps_rt(:,1),rmseps_rt(:,2),'-bo');title('rmseps-RT');
   subplot(2,3,6);plot(wavelength,meanxtrain0,'b-');hold on;plot(wavelength_RT,AAA_x_train_RT,'r*');
   
   %-----------------------------------------------------------------------
   P_UVE                     = polyfit(cmin_uve,y_pred,1);
   yP_UVE                    = polyval(P_UVE,cmin_uve);
   P_MCUVE                   = polyfit(cmin_mcuve,y_pred,1);
   yP_MCUVE                  = polyval(P_MCUVE,cmin_mcuve);
   P_RT                      = polyfit(cmin_rt,y_pred,1);
   yP_RT                     = polyval(P_RT,cmin_rt);    
   text_size                 = 16;   
   figure;
   subplot(1,3,1);
      plot(cmin_uve,y_pred,'o'),grid on; set(gca,'fontsize',text_size); title('UVE','fontsize',text_size+1); xlabel('True','fontsize',text_size); ylabel('Predicted','fontsize',text_size)
      hold on; 
      plot(cmin_uve,yP_UVE,'-r','LineWidth',2); cell_string = [' R=' num2str(r_uve(columm))]; text(min(y_pred)+0.03*(max(y_pred)-min(y_pred)),min(y_pred)+0.97*(max(y_pred)-min(y_pred)),cell_string,'fontsize',text_size-1);
      hold off;
   subplot(1,3,2);
      plot(cmin_mcuve,y_pred,'o'),grid on; set(gca,'fontsize',text_size); title('MCUVE','fontsize',text_size+1); xlabel('True','fontsize',text_size); ylabel('Predicted','fontsize',text_size)
      hold on; 
      plot(cmin_mcuve,yP_MCUVE,'-r','LineWidth',2); cell_string = [' R=' num2str(r_mcuve(columm))]; text(min(y_pred)+0.03*(max(y_pred)-min(y_pred)),min(y_pred)+0.97*(max(y_pred)-min(y_pred)),cell_string,'fontsize',text_size-1);
      hold off;
   subplot(1,3,3);
      plot(cmin_rt,y_pred,'o'),grid on; set(gca,'fontsize',text_size); title('RT','fontsize',text_size+1); xlabel('True','fontsize',text_size); ylabel('Predicted','fontsize',text_size)
      hold on; 
      plot(cmin_rt,yP_RT,'-r','LineWidth',2); cell_string = [' R=' num2str(r_rt(columm))]; text(min(y_pred)+0.03*(max(y_pred)-min(y_pred)),min(y_pred)+0.97*(max(y_pred)-min(y_pred)),cell_string,'fontsize',text_size-1);
      hold off;   
end        