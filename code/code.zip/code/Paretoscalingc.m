
									
function [xmean,xsqrtstd,x_train_Paretoscaling,ymean,ysqrtstd,y_train_Paretoscaling] = Paretoscalingc(x_train,y_train)
xmean = mean(x_train);
ymean = mean(y_train);
xsqrtstd  = sqrt(std(x_train));
ysqrtstd  = sqrt(std(y_train));
[m,n] = size(x_train);
x_train_Paretoscaling = (x_train-ones(m,1)*xmean)./(ones(m,1)*xsqrtstd);
y_train_Paretoscaling = (y_train-repmat(ymean,m,1))./repmat(ysqrtstd,m,1);