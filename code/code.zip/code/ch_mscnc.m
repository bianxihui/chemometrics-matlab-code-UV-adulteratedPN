function [spec,Xmeancal] = ch_mscnc(X)
% POLYFIT Fit polynomial to data.
%          P = POLYFIT(X,Y,N) finds the coefficients of a polynomial P(X) of
%         degree N that fits the data Y best in a least-squares sense. P is a
%         row vector of length N+1 containing the polynomial coefficients in
%         descending powers, P(1)*X^N + P(2)*X^(N-1) +...+ P(N)*X + P(N+1).

% POLYVAL Evaluate polynomial.
%         Y = POLYVAL(P,X) returns the value of a polynomial P evaluated at X. P
%         is a vector of length N+1 whose elements are the coefficients of the
%         polynomial in descending powers.
 
%         Y = P(1)*X^N + P(2)*X^(N-1) + ... + P(N)*X + P(N+1)
 


[n,m]=size(X);
Xmeancal=mean(X);
for i=1:n
  coef = polyfit(X(i,:),Xmeancal,1);
  Xmsc(i,:) = polyval(coef,X(i,:));
end
spec = Xmsc;