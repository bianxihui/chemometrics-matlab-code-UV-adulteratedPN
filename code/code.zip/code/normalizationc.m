% Normalization

function [xmean,xstd,x_train_normalization,ymean,ystd,y_train_normalization]=normalizationc(x_train,y_train)
xmean = mean(x_train);
ymean = mean(y_train);
xstd  = std(x_train);
ystd  = std(y_train);
[m,n] = size(x_train);
x_train_normalization = (x_train-ones(m,1)*xmean)./(ones(m,1)*xstd);
y_train_normalization = (y_train-repmat(ymean,m,1))./repmat(ystd,m,1);