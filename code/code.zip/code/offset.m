									
%# 	To correct (spectra) for a baseline shift.		
%#									
%# PRINCIPLE:	Subtracts individually one (e.g. the first), or the mean	
%#		of any (e.g. first few) variables from each spectrum.	
%#									
%# INPUT:	X - matrix of predictors (spectra) to be corrected	
%#		var1 - (optional) first variable to perform the offset	
%#		var2 - (optional) last variable	to perform the offset	
%#								
%# OUTPUT:	Xoffset - the X-matrix corrected for the baseline shift	
%#		var1 - the first variable used for the correction	
%#		var2 - the last variable used for the correction	
			
									

function [Xoffset,var1,var2]=offset(X,var1,var2);

[n,p]=size(X);

if nargin==1;
   var1=input('The first variable for the offset: ');
   var2=input('The last variables for the offset: ');
end


if var1==var2						% correct or only one variable: var1
	offset=((X(:,var1:var2)')')*ones(1,p);
end
if var1~=var2
	offset=((mean(X(:,var1:var2)'))')*ones(1,p);	% correct for the mean of variables in a defined range: var1-var2
end

Xoffset=X-offset;					% subtraction

end
