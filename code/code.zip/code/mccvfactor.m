function [valPresses_PLS] = mccvfactor(cal,caltar,LV,runtimes)
% Monte Carlo cross validation for factor determination
trainnum               = floor(0.8*length(caltar));
[cala,calb]            = size(cal);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ocal                   = cal; 
ocaltar                = caltar;
TAR_V = [];
for i = 1:runtimes  
    list               = randperm(cala);
    rlist              = list(1:trainnum);
    vlist              = list(trainnum+1:end); 
    samvlist(i,:)      = vlist;
    newcal             = cal(rlist,:);
    newtar             = caltar(rlist);    
    newval             = cal(vlist,:); 
    newvaltar          = caltar(vlist);    
    
    B                  = plsr(newcal, newtar,LV);
    tar_v              = newval*B;
    Press_PLS          = sum(tar_v-newvaltar*ones(1,size(tar_v,2))).^2;    
    Presses_PLS(i,:)   = Press_PLS;
    yy                 = zeros(cala,LV);    
    yy(vlist,:)        = tar_v;
    TAR_V              = [TAR_V yy];    
    clear tar_v   
    cal                = ocal; 
    caltar             = ocaltar;    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
valPresses_PLS          = sum(Presses_PLS)/runtimes;

          


