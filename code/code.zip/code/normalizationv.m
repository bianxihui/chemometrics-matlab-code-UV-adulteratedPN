% Normalization

function [x_pred_normalization]=normalizationv(x_pred,xmean,xstd)
[m,n] = size(x_pred);
x_pred_normalization =(x_pred-ones(m,1)*xmean)./(ones(m,1)*xstd);
