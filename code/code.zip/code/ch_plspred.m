function [c, x] = ch_plspred(x, p, q, w, b, n)
% PLSPRED   Predicts concentrations in unknown spectra.
%
%x = a';
c = 0;
[maxrank, h] = size(p);
if n > maxrank, n = maxrank, end;
for h=1:n
	t(:,h) = x * w(h,:)';
	x = x - t(:,h) * p(h,:);
	c = c + b(h) * t(:,h) * q(h,:);
end
%c = c';
