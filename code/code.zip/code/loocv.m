function [TARV,valpresses]=loocv(cal,caltar,maxrank)

[cala,calb]=size(cal);
ocal=cal; ocaltar=caltar;
presses=[];
TARV=[];
for i=1:cala
    newval=cal(i,:);newvaltar=caltar(i);
    cal(i,:)=[]; caltar(i)=[];
    newcal=cal; newtar=caltar;
    b             = simpls(newcal,newtar,maxrank);
    tar_v         = newval*b(:,maxrank);
    TARV          = [TARV;tar_v];
    press         = sum((tar_v'-newvaltar).^2);
    presses(i,:)  = press;
    press         = [];
    cal=ocal; caltar=ocaltar;
end
valpresses=sum(presses);




