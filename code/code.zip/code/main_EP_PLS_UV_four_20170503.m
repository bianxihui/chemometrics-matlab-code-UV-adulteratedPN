clc;clear;close all
disp('ԭʼ���ݣ���ͬԤ�����������д�����RMSECV,RMSEP,ѵ������Ԥ�⼯��R')
load UV_four_20170503;
meanornot = 1;
mean_method = 1;
switch mean_method
    case 1
       for i = 1:75
        Spectra(i,:)= mean(spectra(2*i-1:2*i,:));             
       end
       Target = target;
    case 2
       Spectra = spectra;
       Target((2*i-1):(2*i))  = target(i); 
end
cal          = Spectra;
caltar       = Target;
[m,n]        = size(cal);
for columm   = 4;
    names   = ynames;
    disp(names{columm});
end
    %---------------------------�ɵ����Ĳ���--------------------------------        
 switch columm
    case 1
         maxrank = 10;
         window0 = 23; window1 = 35; window2 = 77;%���ڣ�ȡ����,��СֵΪ3��
         scalen  = 58; waveletfunction = 'Haar';%С���任�ķֽ�߶ȼ�С������
    case 2
         maxrank = 8;        
         window0 = 27; window1 = 53; window2 = 99;%���ڣ�ȡ����,��СֵΪ3��
         scalen  = 57; waveletfunction = 'Haar';%С���任�ķֽ�߶ȼ�С������
    case 3
         maxrank = 10;
         window0 = 83; window1 = 37; window2 = 87;%���ڣ�ȡ����,��СֵΪ3��
         scalen  = 60; waveletfunction = 'Haar';%С���任�ķֽ�߶ȼ�С������
    case 4
         maxrank = 3;
         window0 = 99; window1 = 99; window2 = 73;%���ڣ�ȡ����,��СֵΪ3��
         scalen  = 60; waveletfunction = 'Haar';%С���任�ķֽ�߶ȼ�С������   
  end 
    [m,n]                           = size(cal);
    %-----------------KS�����ݻ��֣�ѵ����2/3��Ԥ�⼯1/3---------------------
    [model,test]                    = kenstone(cal,floor(2/3*m));
    x_train                         = cal(model,:);
    x_pred                          = cal(test,:);
    y_train                         = caltar(model,columm);
    y_pred                          = caltar(test,columm);
    [m_train,n_train]               = size(x_train);
%----------------------------Ensemble-processing-----------------------
    %baseline = [0 1 2 3];scatter = [0 1 2];smoothing = [0 1]; scaling = [0 1 2 3 4];
    t = 1;
    for baseline = 0:3
        switch baseline
            case 0 %��Ԥ����
            x_train          = x_train;
            x_pred           = x_pred;
            case 1 %һ�׵���
            x_train          = sgdiff(x_train,2,window1,1);
            x_pred           = sgdiff(x_pred,2,window1,1);
            case 2 %���׵���
            x_train          = sgdiff(x_train,2,window2,2);
            x_pred           = sgdiff(x_pred,2,window2,2);
            case 3 %CWT
            x_train          = wavderiv(x_train,waveletfunction,scalen);
            x_pred           = wavderiv(x_pred,waveletfunction,scalen);
        end   
        for scatter = 0:2
           switch scatter
                  case 0 %��Ԥ����
                  x_train        = x_train;
                  x_pred         = x_pred;
                  case 1 %SNV
                  x_train        = snv(x_train);
                  x_pred         = snv(x_pred);
                 case 2
                 [x_train,Xmean] = ch_mscnc(x_train);
                  x_pred         = ch_mscnv(x_pred,Xmean);
           end
           for smoothing = 0:1
                switch smoothing
                      case 0 %��Ԥ����
                      x_train         = x_train;
                      x_pred          = x_pred;
                      case 1 %SGƽ��
%                       x_train         = sgdiff(x_train,2,window0,0);
%                       x_pred          = sgdiff(x_pred,2,window0,0);
                       x_train       = sgdiff(x_train,2,window0,0);
                      x_pred          = sgdiff(x_pred,2,window0,0);
                 end
                for scaling = 0:4
                    switch scaling
                           case 0 %��Ԥ����
                           x_train           = x_train;
                           x_pred            = x_pred;
                           b                 = simpls(x_train,y_train,maxrank);
                           c(:,t)            = x_pred*b(:,maxrank);
                           c_train(:,t)      = loocv(x_train,y_train,maxrank);
                           
                           case 1 % ���Ļ�
                           [xmeancenter,x_train_meancenter,ymean,y_train_meancenter] = meancenterc(x_train,y_train);
                           [x_pred_meancenter] = meancenterv(x_pred,xmeancenter);
                           b                   = simpls(x_train_meancenter,y_train_meancenter,maxrank);
                           c_meancenter        = x_pred_meancenter*b(:,maxrank);
                           c(:,t)              = c_meancenter + repmat(ymean,size(x_pred,1),1);
                           c_train_meancenter  = loocv(x_train_meancenter,y_train_meancenter,maxrank);
                           c_train(:,t)        = c_train_meancenter + repmat(ymean,size(x_train,1),1);
                           case 2  % ��׼��,�Զ���һ��,Pearson��һ��
                           [xmean,xstd,x_train_normalization,ymean,ystd,y_train_normalization] = normalizationc(x_train,y_train);
                           [x_pred_normalization]  = normalizationv(x_pred,xmean,xstd);
                           b                       = simpls(x_train_normalization,y_train_normalization,maxrank);
                           c_normalization         = x_pred_normalization*b(:,maxrank);
                           c(:,t)                  = c_normalization*ystd + repmat(ymean,size(x_pred,1),1);
                           c_train_normalization   = loocv(x_train_normalization,y_train_normalization,maxrank);  
                           c_train(:,t)            = c_train_normalization*ystd + repmat(ymean,size(x_train,1),1);                        
                           case 3 % Pareto��һ��
                           [xmean,xsqrtstd,x_train_Paretoscaling,ymean,ysqrtstd,y_train_Paretoscaling] = Paretoscalingc(x_train,y_train);
                           [x_pred_Paretoscaling]  = Paretoscalingv(x_pred,xmean,xsqrtstd);    
                           b                       = simpls(x_train_Paretoscaling,y_train_Paretoscaling,maxrank);
                           c_Paretoscaling         = x_pred_Paretoscaling*b(:,maxrank);
                           c(:,t)                  = c_Paretoscaling*ysqrtstd  + repmat(ymean,size(x_pred,1),1);
                           c_train_Paretoscaling   = loocv(x_train_Paretoscaling,y_train_Paretoscaling,maxrank);  
                           c_train(:,t)            = c_train_Paretoscaling*ysqrtstd + repmat(ymean,size(x_train,1),1); 
                           case 4 % �����С��һ��
                           [ps_x,x_train_minmaxscaling,ps_y,y_train_minmaxscaling] = minmaxscalingc(x_train,y_train);
                           [x_pred_minmaxscaling]  = minmaxscalingv(x_pred,ps_x);    
                           b                       = simpls(x_train_minmaxscaling,y_train_minmaxscaling,maxrank);
                           c_minmaxscaling         = x_pred_minmaxscaling*b(:,maxrank);
                           c(:,t)                  = (mapminmax('reverse',c_minmaxscaling',ps_y))';    
                           c_train_minmaxscaling   = loocv(x_train_minmaxscaling,y_train_minmaxscaling,maxrank); 
                           c_train(:,t)            = (mapminmax('reverse',c_train_minmaxscaling',ps_y))';   
                               
                    end
                    select(t,:)     = [baseline scatter smoothing scaling];                    
                    rmsecv_each(t)  = rms(c_train(:,t)-y_train);
                    rmsep_each(t)   = rms(c(:,t)-y_pred);
                    R_train         = corrcoef(c_train(:,t),y_train);
                    r_train_each(t) = R_train(1,2);
                    R_pred          = corrcoef(c(:,t),y_pred);
                    r_pred_each(t)  = R_pred(1,2);
                    t               = t+1;      
                end
            end
        end
    end    
    select_ensemble = 0;
    switch select_ensemble
        case 0
        disp('Ԥ��������PLS')    
        ensemble_c_train     = mean(c_train,2);
        ensemble_c           = mean(c,2);        
        case 1
        disp('ѡ����Ԥ��������PLS')
        index_small          = find(rmsep_each<=rmsep_PLS);
        c_train_select       = c_train(:,index_small);
        c_select             = c(:,index_small);
        ensemble_c_train     = mean(c_train_select,2);
        ensemble_c           = mean(c_select,2);
    end
    rmsecv_ensemble      = rms(ensemble_c_train-y_train);
    rmsep_ensemble       = rms(ensemble_c-y_pred);
    R_train              = corrcoef(ensemble_c_train,y_train);
    r_train_ensemble     = R_train(1,2);
    R_pred               = corrcoef(ensemble_c,y_pred);
    r_pred_ensemble      = R_pred(1,2);
   disp([rmsecv_ensemble,rmsep_ensemble,r_train_ensemble,r_pred_ensemble]);
    figure;plot(rmsep_each,'o');title(names{column});
    hold on;
    line([1 t],[rmsep_ensemble rmsep_ensemble]);text(t*0.99,rmsep_ensemble,'rmsep-ensemble');
    line([1 t],[rmsep_PLS rmsep_PLS]);text(t*0.99,rmsep_PLS,'rmsep-PLS'); 
