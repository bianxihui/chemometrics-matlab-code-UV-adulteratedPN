function BB = uvecv(x,y,mcv,maxrank)

[n,m] = size(x);
for i=1:mcv
	mcvlist = i:mcv:n;
    y11 = y;
    x11 = x;
    x22 = x11(mcvlist,:);
    x11(mcvlist,:)=[];
    y11(mcvlist)=[];
    B = simpls(x11, y11, maxrank);
%   cc11(mcvlist) = x22*B(:,maxrank)
    BB(i,:) = B(:,maxrank)';
end
