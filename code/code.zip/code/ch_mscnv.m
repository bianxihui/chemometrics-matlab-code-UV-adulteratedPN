function spec = ch_mscnv(X,Xmeancal)
% line is spectra
[n,m]=size(X);
%Xmeancal=mean(X);
for i=1:n
  coef = polyfit(X(i,:),Xmeancal,1);
  Xmsc(i,:) = polyval(coef,X(i,:));
end
spec = Xmsc;
