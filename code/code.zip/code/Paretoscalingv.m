									
function [x_pred_Paretoscaling] = Paretoscalingv(x_pred,xmean,xsqrtstd)
[m,n] = size(x_pred);
x_pred_Paretoscaling = (x_pred-ones(m,1)*xmean)./(ones(m,1)*xsqrtstd);